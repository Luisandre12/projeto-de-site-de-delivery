Olá! Este é um pequeno site Delivery em construção
do curso de Desenvolvimento Web da Prefeitura Municipal de 
Belo Horizonte.

Como uma forma de praticar os conteúdos abordados em HTML e CSS.